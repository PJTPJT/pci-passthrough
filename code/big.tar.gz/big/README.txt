Big
---
- host: direct interrupt delivery
- guest: direct interrupt delivery + bonding driver
